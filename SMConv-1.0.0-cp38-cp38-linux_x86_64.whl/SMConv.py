import math
import torch
import numpy as np
import torch.nn as nn
import torch.nn.init as init
from torch.autograd import Function
from torch.autograd.function import once_differentiable
from torch.nn.modules.utils import _pair,_triple
import SMConv_CUDA
import os
import torch.nn.functional as F

class DeformConv3dFunction(Function):
    @staticmethod
    def forward(ctx, input, cosine, mask, weight, bias=None, stride=1, padding=0, dilation=1,
                groups=1, deformable_groups=1 , in_step=1,scale=0.1):
        ctx.stride = stride
        ctx.padding = padding
        ctx.dilation = dilation
        ctx.kernel_size = weight.size()[2]
        ctx.groups = groups
        ctx.deformable_groups = deformable_groups
        ctx.in_step = in_step
        ctx.with_bias = bias is not None
        ctx.scale=scale
        if not ctx.with_bias:
            bias = input.new_empty(0)  # fake tensor
        if not input.is_cuda:
            raise NotImplementedError
        if weight.requires_grad or cosine.requires_grad or mask.requires_grad or input.requires_grad:
            ctx.save_for_backward(input, cosine, mask, weight, bias)
        output = input.new_empty(DeformConv3dFunction._infer_shape(ctx, input, weight))
    
        SMConv_CUDA.deform_conv3d_forward_cuda(
            input, weight, bias, cosine, mask, output,
            ctx.kernel_size,
            ctx.stride,
            ctx.padding,
            ctx.dilation,
            ctx.groups, ctx.deformable_groups,ctx.in_step, ctx.with_bias)

        return output

    @staticmethod
    @once_differentiable
    def backward(ctx, grad_output):
        grad_output=grad_output.contiguous()
        # print(grad_output)
        if not grad_output.is_cuda:
            raise NotImplementedError
        input, cosine, mask, weight, bias = ctx.saved_tensors
        grad_input = torch.zeros_like(input)
        grad_cosine = torch.zeros_like(cosine)
        grad_weight = torch.zeros_like(weight)
        grad_bias = torch.zeros_like(bias)
        grad_mask = torch.zeros_like(mask)
        SMConv_CUDA.deform_conv3d_backward_cuda(
            input, weight, bias, cosine, mask,
            grad_input, grad_weight,grad_bias,grad_cosine, grad_mask, grad_output,
            ctx.kernel_size,
            ctx.stride,
            ctx.padding,
            ctx.dilation,
            ctx.groups, ctx.deformable_groups,ctx.in_step,ctx.with_bias)

        if not ctx.with_bias:
            grad_bias = None
        else:
            grad_bias = torch.tensor(ctx.scale)*grad_bias
        grad_input = torch.tensor(ctx.scale)*grad_input
        grad_cosine = torch.tensor(ctx.scale)*grad_cosine
        # grad_weight = torch.tensor(ctx.scale)*grad_weight
        grad_mask = torch.tensor(ctx.scale)*grad_mask
        return (grad_input, grad_cosine, grad_mask, grad_weight, grad_bias, None, None, None, None, None,None,None,None)


    @staticmethod
    def _infer_shape(ctx, input, weight):
        n = input.size(0)
        channels_out = weight.size(0)
        height, width,length = input.shape[2:5]
        height_out = (height + 2 * ctx.padding - (ctx.dilation * (ctx.kernel_size - 1) + 1)) // ctx.stride + 1
        width_out = (width + 2 * ctx.padding - (ctx.dilation * (ctx.kernel_size - 1) + 1)) // ctx.stride + 1
        length_out = (length + 2 * ctx.padding - (ctx.dilation * (ctx.kernel_size - 1) + 1)) // ctx.stride + 1
        return n, channels_out, height_out, width_out, length_out

deform_conv3d = DeformConv3dFunction.apply


class DeformConv3d(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size=9, stride=1, padding=4, dilation=1,
                 groups=1, deformable_groups=1, bias=False,in_step=1, scale=0.1):
        super(DeformConv3d, self).__init__()
        assert in_channels % groups == 0, \
            'in_channels {} cannot be divisible by groups {}'.format(
                in_channels, groups)
        assert out_channels % groups == 0, \
            'out_channels {} cannot be divisible by groups {}'.format(
                out_channels, groups)

        self.in_channels = in_channels
        self.out_channels = out_channels
        self.kernel_size = kernel_size
        self.stride = stride
        self.padding = padding
        self.dilation = dilation
        self.groups = groups
        self.deformable_groups = deformable_groups
        self.in_step=in_step
        self.scale = scale
        
        self.weight = nn.Parameter(
            torch.Tensor(out_channels, in_channels // self.groups, *(self.kernel_size,1,1)))
        
        self.conv_mask = nn.Conv3d(in_channels, kernel_size, kernel_size=3,
                                  stride=1, padding=1, dilation=1, bias=False)
        self.sigmoid = nn.Sigmoid()


        self.with_bias=bias
        if self.with_bias:
            self.bias = nn.Parameter(torch.Tensor(out_channels))
        else:
            self.bias=None

        self.reset_parameters()

    def reset_parameters(self):
        n = self.in_channels
        for k in (1,1,self.kernel_size):
            n *= k
        stdv = 1. / math.sqrt(n)
        self.weight.data.uniform_(-stdv, stdv)
        # self.weight.data.fill_(1)
        if self.with_bias:
            self.bias.data.fill_(0)

    def forward(self, x, cosine):
        mask = self.conv_mask(x)
        mask = 0.1 + 0.9*self.sigmoid(mask)
        return deform_conv3d(x, cosine, mask, self.weight, self.bias, self.stride, self.padding, self.dilation,
                        self.groups, self.deformable_groups,self.in_step,self.scale)

